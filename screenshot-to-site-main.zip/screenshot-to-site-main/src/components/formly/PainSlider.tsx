import { AnimatePresence, motion } from "framer-motion";
import { AlertCircle } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { isPainHigh } from "@/lib/mock";

export function PainSlider({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <div className="mb-3 flex items-end justify-between">
        <span className="text-sm font-semibold">Tingkat nyeri</span>
        <span className="text-3xl font-extrabold text-primary">{value}<span className="text-base text-muted-foreground">/10</span></span>
      </div>
      <Slider value={[value]} min={0} max={10} step={1} onValueChange={(v) => onChange(v[0] ?? 0)} aria-label="Tingkat nyeri" />
      <div className="mt-2 flex justify-between text-xs font-medium text-muted-foreground"><span>Tidak nyeri</span><span>Sangat nyeri</span></div>
      <AnimatePresence>
        {isPainHigh(value) && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
            className="glass mt-4 flex gap-3 rounded-3xl p-4 text-sm">
            <AlertCircle className="size-5 shrink-0 text-warning" strokeWidth={1.75} />
            <span>Nyeri cukup tinggi. Sebaiknya istirahat dan hubungi terapismu.</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

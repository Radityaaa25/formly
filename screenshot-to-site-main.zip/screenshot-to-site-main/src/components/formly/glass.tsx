import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { useEffect, useState, type ComponentProps, type ReactNode } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { Home, Dumbbell, LineChart, User, Lock, Award } from "lucide-react";
import { cn } from "@/lib/utils";

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-end font-bold lowercase tracking-tight text-foreground", className)}>
      formly
      <span className="mb-[0.18em] ml-0.5 inline-block size-[0.28em] rounded-full bg-sky" />
    </span>
  );
}

export function GlassCard({ className, ...p }: ComponentProps<"div">) {
  return <div className={cn("glass rounded-3xl p-5", className)} {...p} />;
}

type BtnProps = ComponentProps<typeof motion.button> & { variant?: "primary" | "secondary" | "danger"; size?: "md" | "lg" };
export function GlassButton({ className, variant = "primary", size = "md", ...p }: BtnProps) {
  return (
    <motion.button
      whileTap={{ scale: 0.97 }}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-5 font-semibold transition-colors disabled:opacity-50",
        size === "lg" && "min-h-14 px-7 text-base",
        variant === "primary" && "btn-gloss bg-primary text-primary-foreground",
        variant === "secondary" && "glass text-primary",
        variant === "danger" && "glass text-destructive",
        className,
      )}
      {...p}
    />
  );
}

export function Chip({ active, className, ...p }: ComponentProps<"button"> & { active?: boolean }) {
  return (
    <button
      className={cn(
        "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full px-4 text-sm font-medium transition-colors",
        active ? "bg-primary text-primary-foreground btn-gloss" : "glass text-foreground",
        className,
      )}
      {...p}
    />
  );
}

export function StatusBadge({ tone, children }: { tone: "success" | "warning" | "muted" | "primary"; children: ReactNode }) {
  const map = {
    success: "bg-success/12 text-success",
    warning: "bg-warning/15 text-warning",
    muted: "bg-muted text-muted-foreground",
    primary: "bg-primary/10 text-primary",
  };
  return <span className={cn("inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold", map[tone])}>{children}</span>;
}

export function CountUp({ to, className }: { to: number; className?: string }) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => Math.round(v));
  const [val, setVal] = useState(0);
  useEffect(() => {
    const c = animate(mv, to, { duration: 0.9, ease: "easeOut" });
    const u = rounded.on("change", setVal);
    return () => { c.stop(); u(); };
  }, [to, mv, rounded]);
  return <span className={className}>{val}</span>;
}

export function StatRing({ value, max, size = 96, stroke = 9, children }: { value: number; max: number; size?: number; stroke?: number; children?: ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--accent)" strokeWidth={stroke} fill="none" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} stroke="var(--primary)" strokeWidth={stroke} fill="none" strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - value / max) }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

const WEEK = ["S", "S", "R", "K", "J", "S", "M"];
export function StreakWeek({ active, today }: { active: boolean[]; today: number }) {
  return (
    <div className="flex justify-between">
      {WEEK.map((d, i) => (
        <div key={i} className="flex flex-col items-center gap-1.5">
          <span className="text-xs font-medium text-muted-foreground">{d}</span>
          <span
            className={cn(
              "size-7 rounded-full",
              active[i] ? "bg-primary btn-gloss" : i === today ? "border-2 border-sky bg-sky/15" : "bg-accent",
            )}
          />
        </div>
      ))}
    </div>
  );
}

export function ProgressBar({ value, max }: { value: number; max: number }) {
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-accent">
      <motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} animate={{ width: `${(value / max) * 100}%` }} transition={{ duration: 0.9 }} />
    </div>
  );
}

export function BadgeTile({ label, unlocked }: { label: string; unlocked: boolean }) {
  return (
    <div className={cn("glass flex flex-col items-center gap-2 rounded-3xl p-3 text-center", !unlocked && "opacity-55")}>
      <div className={cn("grid size-12 place-items-center rounded-full", unlocked ? "bg-primary text-primary-foreground btn-gloss" : "bg-muted text-muted-foreground")}>
        {unlocked ? <Award className="size-6" strokeWidth={1.75} /> : <Lock className="size-5" strokeWidth={1.75} />}
      </div>
      <span className="text-xs font-semibold leading-tight">{label}</span>
    </div>
  );
}

export function ChatBubble({ from, children }: { from: "user" | "ai"; children: ReactNode }) {
  return (
    <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={cn("flex", from === "user" ? "justify-end" : "justify-start")}>
      <div className={cn("max-w-[80%] rounded-3xl px-4 py-3 text-[15px] leading-relaxed", from === "user" ? "rounded-br-lg bg-primary text-primary-foreground btn-gloss" : "glass rounded-bl-lg")}>
        {children}
      </div>
    </motion.div>
  );
}

const NAV = [
  { to: "/beranda", label: "Beranda", icon: Home },
  { to: "/latihan", label: "Latihan", icon: Dumbbell },
  { to: "/progres", label: "Progres", icon: LineChart },
  { to: "/profil", label: "Profil", icon: User },
] as const;

export function GlassNav() {
  const { pathname } = useLocation();
  return (
    <nav className="glass absolute inset-x-4 bottom-4 z-30 flex justify-between rounded-full p-1.5">
      {NAV.map(({ to, label, icon: Icon }) => {
        const active = pathname.startsWith(to) || (to === "/beranda" && pathname === "/rehab");
        const target = to === "/beranda" && pathname === "/rehab" ? "/rehab" : to;
        return (
          <Link key={to} to={target} className="relative flex min-h-12 flex-1 flex-col items-center justify-center gap-0.5 rounded-full">
            {active && <motion.span layoutId="nav-ind" className="absolute inset-0 rounded-full bg-primary/12 ring-1 ring-primary/20" />}
            <Icon className={cn("relative size-5", active ? "text-primary" : "text-muted-foreground")} strokeWidth={1.75} />
            <span className={cn("relative text-[11px] font-semibold", active ? "text-primary" : "text-muted-foreground")}>{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

/** Scrollable screen with tab nav. */
export function TabScreen({ children, nav = true }: { children: ReactNode; nav?: boolean }) {
  return (
    <>
      <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} className={cn("no-scrollbar h-full overflow-y-auto px-5 pt-12", nav ? "pb-28" : "pb-10")}>
        {children}
      </motion.main>
      {nav && <GlassNav />}
    </>
  );
}

export function ScreenTitle({ children, sub }: { children: ReactNode; sub?: ReactNode }) {
  return (
    <header className="mb-6">
      <h1 className="text-[30px] font-bold leading-tight tracking-tight">{children}</h1>
      {sub && <p className="mt-1 text-[15px] text-muted-foreground">{sub}</p>}
    </header>
  );
}

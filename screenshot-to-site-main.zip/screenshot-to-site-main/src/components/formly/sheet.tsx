import { AnimatePresence, motion } from "framer-motion";
import type { ReactNode } from "react";

export function BottomSheet({ open, onClose, children }: { open: boolean; onClose?: () => void; children: ReactNode }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div className="absolute inset-0 z-40 bg-navy/30" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
          <motion.div
            role="dialog"
            className="glass absolute inset-x-0 bottom-0 z-50 rounded-t-4xl bg-background/85 px-6 pb-8 pt-3"
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 30, stiffness: 300 }}
          >
            <div className="mx-auto mb-5 h-1.5 w-10 rounded-full bg-muted-foreground/30" />
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

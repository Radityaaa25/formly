import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import type { ReactNode } from "react";

export function TherapistShell({ title, back, action, children }: { title: string; back?: boolean; action?: ReactNode; children: ReactNode }) {
  return (
    <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="no-scrollbar h-full overflow-y-auto px-4 pb-10 pt-12">
      <header className="mb-5 flex items-center gap-3">
        {back ? (
          <Link to="/terapis" aria-label="Kembali" className="glass grid size-11 place-items-center rounded-full"><ArrowLeft className="size-5" strokeWidth={1.75} /></Link>
        ) : (
          <Link to="/" aria-label="Ganti peran" className="glass grid size-11 place-items-center rounded-full"><ArrowLeft className="size-5" strokeWidth={1.75} /></Link>
        )}
        <h1 className="flex-1 text-2xl font-bold tracking-tight">{title}</h1>
        {action}
      </header>
      {children}
    </motion.main>
  );
}

import { Activity, ArrowUpFromLine, Dumbbell, Footprints, MoveHorizontal, PersonStanding, RotateCw, StretchHorizontal } from "lucide-react";
import type { Exercise } from "@/lib/mock";

const map = {
  squat: PersonStanding,
  pushup: Dumbbell,
  plank: StretchHorizontal,
  arm: ArrowUpFromLine,
  lunge: Footprints,
  bridge: MoveHorizontal,
  knee: Activity,
  shoulder: RotateCw,
};

export function ExerciseIcon({ icon, className }: { icon: Exercise["icon"]; className?: string }) {
  const I = map[icon];
  return <I className={className} strokeWidth={1.75} />;
}

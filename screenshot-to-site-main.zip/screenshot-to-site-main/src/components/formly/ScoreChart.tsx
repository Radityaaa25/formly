import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function ScoreChart({ data }: { data: { d: string; skor: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={160}>
      <LineChart data={data.map((x) => ({ ...x, skor: x.skor || null }))} margin={{ left: -24, right: 8, top: 8 }}>
        <XAxis dataKey="d" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
        <YAxis domain={[50, 100]} tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
        <Tooltip contentStyle={{ borderRadius: 16, border: "none" }} />
        <Line type="monotone" dataKey="skor" stroke="var(--primary)" strokeWidth={3} dot={{ r: 4, fill: "var(--primary)" }} connectNulls />
      </LineChart>
    </ResponsiveContainer>
  );
}


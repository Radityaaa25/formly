import { describe, expect, it } from "vitest";
import { isPainHigh } from "@/lib/mock";

describe("pain alert", () => {
  it("shows at 7", () => expect(isPainHigh(7)).toBe(true));
  it("does not show at 6", () => expect(isPainHigh(6)).toBe(false));
});

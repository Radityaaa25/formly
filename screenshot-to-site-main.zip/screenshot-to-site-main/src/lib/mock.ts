export type Exercise = {
  id: string;
  name: string;
  difficulty: "Mudah" | "Sedang" | "Sulit";
  side: "Samping" | "Depan";
  icon: "squat" | "pushup" | "plank" | "arm" | "lunge" | "bridge" | "knee" | "shoulder";
  placement: string;
  tips: string[];
};

export const exercises: Exercise[] = [
  { id: "squat", name: "Squat", difficulty: "Sedang", side: "Samping", icon: "squat", placement: "Taruh HP setinggi pinggang, 2-3 meter di samping badan.", tips: ["Punggung tetap lurus", "Lutut searah ujung kaki", "Turun sampai paha sejajar lantai"] },
  { id: "pushup", name: "Push-up", difficulty: "Sedang", side: "Samping", icon: "pushup", placement: "Taruh HP di lantai, 2 meter di samping badan.", tips: ["Badan lurus dari kepala ke tumit", "Siku sekitar 45°", "Dada hampir menyentuh lantai"] },
  { id: "plank", name: "Plank", difficulty: "Mudah", side: "Samping", icon: "plank", placement: "Taruh HP di lantai, 2 meter di samping badan.", tips: ["Pinggul jangan turun", "Tarik perut ke dalam", "Napas tetap teratur"] },
  { id: "arm", name: "Angkat Lengan", difficulty: "Mudah", side: "Depan", icon: "arm", placement: "Taruh HP setinggi dada, 2 meter di depan badan.", tips: ["Bahu tetap rileks", "Angkat perlahan", "Siku sedikit ditekuk"] },
  { id: "lunge", name: "Lunge", difficulty: "Sulit", side: "Samping", icon: "lunge", placement: "Taruh HP setinggi pinggang, 3 meter di samping badan.", tips: ["Lutut depan tidak melewati ujung kaki", "Badan tegak", "Langkah cukup lebar"] },
  { id: "bridge", name: "Glute Bridge", difficulty: "Mudah", side: "Samping", icon: "bridge", placement: "Taruh HP di lantai, 2 meter di samping badan.", tips: ["Dorong lewat tumit", "Tahan 2 detik di atas", "Jangan melengkungkan punggung"] },
  { id: "knee", name: "Tekuk Lutut", difficulty: "Mudah", side: "Samping", icon: "knee", placement: "Taruh HP setinggi lutut, 2 meter di samping badan.", tips: ["Gerak perlahan", "Berhenti bila nyeri tajam", "Paha tetap diam"] },
  { id: "shoulder", name: "Putar Bahu", difficulty: "Mudah", side: "Depan", icon: "shoulder", placement: "Taruh HP setinggi dada, 2 meter di depan badan.", tips: ["Lingkaran kecil dulu", "Leher rileks", "Kedua sisi sama rata"] },
];

export const weekScores = [
  { d: "Sen", skor: 72, rep: 40 },
  { d: "Sel", skor: 78, rep: 55 },
  { d: "Rab", skor: 75, rep: 30 },
  { d: "Kam", skor: 81, rep: 60 },
  { d: "Jum", skor: 84, rep: 48 },
  { d: "Sab", skor: 0, rep: 0 },
  { d: "Min", skor: 86, rep: 30 },
];

export const rehabProgram = [
  { id: "knee", name: "Tekuk Lutut", sets: 3, reps: 10, done: true },
  { id: "bridge", name: "Glute Bridge", sets: 2, reps: 12, done: false },
  { id: "shoulder", name: "Putar Bahu", sets: 2, reps: 8, done: false },
];

export type Patient = {
  id: string;
  name: string;
  condition: string;
  status: "Rutin" | "Perlu perhatian" | "Tidak aktif";
  adherence: number;
  lastSession: string;
  scores: number[];
  errors: string[];
};

export const patients: Patient[] = [
  { id: "sari", name: "Sari Wulandari", condition: "Pasca operasi ACL lutut kanan", status: "Rutin", adherence: 83, lastSession: "Hari ini", scores: [70, 74, 77, 80, 82, 85, 86], errors: ["Lutut masuk ke dalam", "Gerak terlalu cepat"] },
  { id: "budi", name: "Budi Santoso", condition: "Frozen shoulder kiri", status: "Perlu perhatian", adherence: 50, lastSession: "3 hari lalu", scores: [65, 62, 68, 60, 64, 0, 0], errors: ["Bahu terangkat", "Rentang gerak kurang"] },
  { id: "ayu", name: "Ayu Lestari", condition: "Nyeri punggung bawah", status: "Rutin", adherence: 92, lastSession: "Kemarin", scores: [78, 80, 83, 85, 84, 88, 90], errors: ["Pinggul turun saat bridge"] },
  { id: "hendra", name: "Hendra Gunawan", condition: "Pemulihan sprain pergelangan kaki", status: "Tidak aktif", adherence: 10, lastSession: "12 hari lalu", scores: [60, 0, 0, 0, 0, 0, 0], errors: ["Keseimbangan kurang"] },
];

export const badges = [
  { id: "s3", label: "3 Hari Beruntun", unlocked: true },
  { id: "s7", label: "7 Hari Beruntun", unlocked: true },
  { id: "s14", label: "14 Hari Beruntun", unlocked: false },
  { id: "s30", label: "30 Hari Beruntun", unlocked: false },
  { id: "s100", label: "100 Hari Beruntun", unlocked: false },
  { id: "skor90", label: "Skor 90+", unlocked: false },
  { id: "rep100", label: "100 Rep Pertama", unlocked: true },
];

/** Monthly calendar: November 2026 starts on Sunday. */
export const monthDays: Record<number, "active" | "frozen" | "rest"> = {
  2: "active", 3: "active", 4: "rest", 5: "active", 6: "active", 7: "active",
  9: "active", 10: "frozen", 11: "active", 12: "active", 13: "active", 14: "active",
  15: "active", 16: "active", 17: "active", 18: "active", 19: "active", 20: "active",
  21: "rest", 22: "active", 23: "active", 24: "active", 25: "active", 26: "active",
};

/** Pain level at or above this shows the rest alert. */
export const PAIN_ALERT_THRESHOLD = 7;
export const isPainHigh = (v: number) => v >= PAIN_ALERT_THRESHOLD;

export const statusTone = (s: Patient["status"]): "success" | "warning" | "muted" =>
  s === "Rutin" ? "success" : s === "Perlu perhatian" ? "warning" : "muted";

import { createContext, useContext, useState, type ReactNode } from "react";

export type Mode = "workout" | "rehab";

type AppState = {
  mode: Mode;
  setMode: (m: Mode) => void;
};

const Ctx = createContext<AppState | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<Mode>("workout");
  return <Ctx.Provider value={{ mode, setMode }}>{children}</Ctx.Provider>;
}

export function useAppState() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAppState outside provider");
  return c;
}

import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts";
import { ScoreChart } from "@/components/formly/ScoreChart";
import { BadgeTile, GlassCard, ScreenTitle, TabScreen } from "@/components/formly/glass";
import { badges, monthDays, weekScores } from "@/lib/mock";
import { useAppState } from "@/lib/app-state";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/progres")({
  head: () => ({
    meta: [
      { title: "Progres — Formly" },
      { name: "description", content: "Grafik skor form, volume rep, kalender aktif, dan badge." },
      { property: "og:title", content: "Progres — Formly" },
      { property: "og:description", content: "Lihat perkembangan latihanmu." },
    ],
  }),
  component: Progres,
});

function Progres() {
  const { mode } = useAppState();
  return (
    <TabScreen>
      <ScreenTitle sub="Minggu ini">Progres</ScreenTitle>

      <GlassCard>
        <h2 className="mb-2 text-sm font-semibold">Skor form</h2>
        <ScoreChart data={weekScores} />
      </GlassCard>

      <GlassCard className="mt-4">
        <h2 className="mb-2 text-sm font-semibold">Volume rep</h2>
        <ResponsiveContainer width="100%" height={140}>
          <BarChart data={weekScores} margin={{ left: -24, right: 8, top: 8 }}>
            <XAxis dataKey="d" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
            <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
            <Bar dataKey="rep" fill="var(--sky)" radius={[8, 8, 8, 8]} />
          </BarChart>
        </ResponsiveContainer>
      </GlassCard>

      <GlassCard className="mt-4">
        <h2 className="mb-4 text-sm font-semibold">November 2026</h2>
        <div className="grid grid-cols-7 gap-1.5 text-center">
          {["M", "S", "S", "R", "K", "J", "S"].map((d, i) => <span key={i} className="text-xs font-medium text-muted-foreground">{d}</span>)}
          {Array.from({ length: 30 }, (_, i) => i + 1).map((day) => {
            const s = monthDays[day];
            return (
              <span key={day} className={cn("grid aspect-square place-items-center rounded-full text-sm font-medium",
                s === "active" && "bg-primary text-primary-foreground",
                s === "frozen" && "bg-sky/25 text-primary",
                s === "rest" && "bg-muted text-muted-foreground",
                !s && "text-muted-foreground")}>{day}</span>
            );
          })}
        </div>
        <div className="mt-4 flex gap-4 text-xs font-medium text-muted-foreground">
          <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-primary" />Aktif</span>
          <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-sky/40" />Freeze</span>
          <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-full bg-muted-foreground/30" />Istirahat</span>
        </div>
        <p className="mt-3 text-sm text-muted-foreground">Istirahat itu bagian dari latihan.</p>
      </GlassCard>

      {mode === "workout" && (
        <>
          <h2 className="mb-3 mt-7 text-sm font-semibold text-muted-foreground">Badge</h2>
          <div className="grid grid-cols-3 gap-3">
            {badges.map((b) => <BadgeTile key={b.id} {...b} />)}
          </div>
        </>
      )}
    </TabScreen>
  );
}

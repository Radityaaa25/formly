import { createFileRoute, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { GlassButton, GlassCard, StatRing, StatusBadge } from "@/components/formly/glass";
import { TherapistShell } from "@/components/formly/TherapistShell";
import { ScoreChart } from "@/components/formly/ScoreChart";
import { patients, statusTone } from "@/lib/mock";

export const Route = createFileRoute("/terapis/$id")({
  loader: ({ params }) => {
    const p = patients.find((x) => x.id === params.id);
    if (!p) throw notFound();
    return p;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.name ?? "Pasien"} — Formly Terapis` },
      { name: "description", content: "Detail skor form, kesalahan, dan kepatuhan pasien." },
      { property: "og:title", content: `${loaderData?.name ?? "Pasien"} — Formly Terapis` },
      { property: "og:description", content: "Detail perkembangan pasien." },
    ],
  }),
  component: Detail,
});

const days = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];

function Detail() {
  const p = Route.useLoaderData();
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState(false);
  return (
    <TherapistShell title={p.name.split(" ")[0]} back>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{p.condition}</p>
        <StatusBadge tone={statusTone(p.status)}>{p.status}</StatusBadge>
      </div>
      <div className="grid grid-cols-[auto_1fr] gap-3">
        <GlassCard className="flex flex-col items-center gap-1 p-4">
          <StatRing value={p.adherence} max={100} size={80} stroke={8}><span className="text-lg font-bold">{p.adherence}%</span></StatRing>
          <span className="text-xs font-medium text-muted-foreground">Kepatuhan</span>
        </GlassCard>
        <GlassCard className="p-4">
          <h2 className="mb-2 text-xs font-semibold text-muted-foreground">Kesalahan tersering</h2>
          <ul className="space-y-1.5 text-sm">{p.errors.map((e) => <li key={e as string}>• {e}</li>)}</ul>
        </GlassCard>
      </div>
      <GlassCard className="mt-3 p-4">
        <h2 className="mb-1 text-sm font-semibold">Skor form mingguan</h2>
        <ScoreChart data={p.scores.map((skor, i) => ({ d: days[i] ?? "", skor }))} />
      </GlassCard>
      <GlassCard className="mt-3 p-4">
        <h2 className="mb-2 text-sm font-semibold">Catatan</h2>
        <textarea value={note} onChange={(e) => { setNote(e.target.value); setSaved(false); }} rows={3} placeholder="Tulis catatan untuk pasien…"
          className="w-full resize-none rounded-2xl bg-card/70 p-3 text-[15px] outline-none ring-primary/30 focus:ring-2" />
        <GlassButton className="mt-2" onClick={() => setSaved(true)}>{saved ? "Tersimpan" : "Simpan catatan"}</GlassButton>
      </GlassCard>
    </TherapistShell>
  );
}

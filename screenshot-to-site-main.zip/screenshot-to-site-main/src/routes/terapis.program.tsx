import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pencil, Trash2, Minus, Plus } from "lucide-react";
import { GlassButton, GlassCard } from "@/components/formly/glass";
import { TherapistShell } from "@/components/formly/TherapistShell";
import { exercises, patients } from "@/lib/mock";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/terapis/program")({
  head: () => ({
    meta: [
      { title: "Buat Program — Formly Terapis" },
      { name: "description", content: "Buat dan kelola program latihan pasien." },
      { property: "og:title", content: "Buat Program — Formly Terapis" },
      { property: "og:description", content: "Buat dan kelola program latihan pasien." },
    ],
  }),
  component: Program,
});

type Prog = { id: number; patient: string; exIds: string[]; sets: number; reps: number; days: string[] };
const DAYS = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];

function Stepper({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="flex-1">
      <div className="mb-1.5 text-xs font-semibold text-muted-foreground">{label}</div>
      <div className="flex items-center justify-between rounded-full bg-accent p-1">
        <button aria-label={`Kurangi ${label}`} onClick={() => onChange(Math.max(1, value - 1))} className="grid size-10 place-items-center rounded-full bg-card"><Minus className="size-4" strokeWidth={1.75} /></button>
        <span className="text-lg font-bold">{value}</span>
        <button aria-label={`Tambah ${label}`} onClick={() => onChange(value + 1)} className="grid size-10 place-items-center rounded-full bg-card"><Plus className="size-4" strokeWidth={1.75} /></button>
      </div>
    </div>
  );
}

const empty = { patient: patients[0]!.id, exIds: [] as string[], sets: 3, reps: 10, days: ["Sen", "Rab", "Jum"] };

function Program() {
  const [list, setList] = useState<Prog[]>([
    { id: 1, patient: "sari", exIds: ["knee", "bridge", "shoulder"], sets: 3, reps: 10, days: ["Sen", "Rab", "Jum", "Sab"] },
    { id: 2, patient: "budi", exIds: ["shoulder", "arm"], sets: 2, reps: 8, days: ["Sel", "Kam", "Sab"] },
  ]);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState<number | null>(null);

  const toggle = (k: "exIds" | "days", v: string) =>
    setForm((f) => ({ ...f, [k]: f[k].includes(v) ? f[k].filter((x) => x !== v) : [...f[k], v] }));

  const save = () => {
    if (!form.exIds.length) return;
    if (editing) setList((l) => l.map((p) => (p.id === editing ? { ...form, id: editing } : p)));
    else setList((l) => [...l, { ...form, id: Date.now() }]);
    setForm(empty); setEditing(null);
  };

  return (
    <TherapistShell title="Buat Program" back>
      <GlassCard className="space-y-5 p-4">
        <div>
          <div className="mb-1.5 text-xs font-semibold text-muted-foreground">Pasien</div>
          <select value={form.patient} onChange={(e) => setForm({ ...form, patient: e.target.value })} className="min-h-11 w-full rounded-full bg-accent px-4 font-semibold outline-none">
            {patients.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        <div>
          <div className="mb-1.5 text-xs font-semibold text-muted-foreground">Gerakan</div>
          <div className="flex flex-wrap gap-2">
            {exercises.map((e) => (
              <button key={e.id} onClick={() => toggle("exIds", e.id)}
                className={cn("min-h-10 rounded-full px-3.5 text-sm font-medium", form.exIds.includes(e.id) ? "bg-primary text-primary-foreground" : "bg-accent text-foreground")}>{e.name}</button>
            ))}
          </div>
        </div>
        <div className="flex gap-3">
          <Stepper label="Set" value={form.sets} onChange={(sets) => setForm({ ...form, sets })} />
          <Stepper label="Rep" value={form.reps} onChange={(reps) => setForm({ ...form, reps })} />
        </div>
        <div>
          <div className="mb-1.5 text-xs font-semibold text-muted-foreground">Hari</div>
          <div className="flex justify-between">
            {DAYS.map((d) => (
              <button key={d} onClick={() => toggle("days", d)}
                className={cn("grid size-11 place-items-center rounded-full text-xs font-semibold", form.days.includes(d) ? "bg-primary text-primary-foreground" : "bg-accent text-muted-foreground")}>{d}</button>
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          {editing && <GlassButton variant="secondary" className="flex-1" onClick={() => { setEditing(null); setForm(empty); }}>Batal</GlassButton>}
          <GlassButton className="flex-1" onClick={save} disabled={!form.exIds.length}>{editing ? "Simpan perubahan" : "Buat Program"}</GlassButton>
        </div>
      </GlassCard>

      <h2 className="mb-3 mt-6 text-sm font-semibold text-muted-foreground">Program aktif</h2>
      <div className="space-y-2.5">
        {list.map((p) => (
          <GlassCard key={p.id} className="flex items-center gap-2 p-4">
            <div className="min-w-0 flex-1">
              <div className="font-semibold">{patients.find((x) => x.id === p.patient)?.name}</div>
              <div className="truncate text-xs text-muted-foreground">
                {p.exIds.map((id) => exercises.find((e) => e.id === id)?.name).join(", ")} · {p.sets}×{p.reps} · {p.days.join(" ")}
              </div>
            </div>
            <button aria-label="Ubah" onClick={() => { setEditing(p.id); setForm(p); }} className="grid size-11 place-items-center rounded-full text-primary"><Pencil className="size-4" strokeWidth={1.75} /></button>
            <button aria-label="Hapus" onClick={() => setList((l) => l.filter((x) => x.id !== p.id))} className="grid size-11 place-items-center rounded-full text-destructive"><Trash2 className="size-4" strokeWidth={1.75} /></button>
          </GlassCard>
        ))}
      </div>
    </TherapistShell>
  );
}

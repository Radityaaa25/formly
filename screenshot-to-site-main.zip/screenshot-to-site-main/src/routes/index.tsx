import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { Camera, Mic, TrendingUp, Dumbbell, HeartPulse, Stethoscope, ChevronRight } from "lucide-react";
import { GlassButton, GlassCard, Wordmark } from "@/components/formly/glass";
import { useAppState } from "@/lib/app-state";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Formly — Mulai" },
      { name: "description", content: "Kenali Formly: kamera jadi mata, suara jadi pelatih, progres terlihat jelas." },
      { property: "og:title", content: "Formly — Mulai" },
      { property: "og:description", content: "Kamera jadi mata, suara jadi pelatih, progres terlihat jelas." },
    ],
  }),
  component: Onboarding,
});

const slides = [
  { icon: Camera, title: "Kamera jadi mata", text: "AI di HP-mu menghitung rep dan membaca gerakan. Video tidak pernah disimpan." },
  { icon: Mic, title: "Suara jadi pelatih", text: "Koreksi form langsung lewat suara, tanpa perlu melihat layar." },
  { icon: TrendingUp, title: "Progres terlihat jelas", text: "Skor form, rep, dan konsistensi tercatat rapi setiap hari." },
];

function Illustration({ Icon }: { Icon: typeof Camera }) {
  return (
    <div className="relative mx-auto grid size-64 place-items-center">
      <div className="absolute size-56 rounded-full bg-sky/25 blur-2xl" />
      <div className="glass absolute left-4 top-6 size-24 rounded-[32px] rotate-[-12deg]" />
      <div className="glass absolute bottom-6 right-4 size-20 rounded-full" />
      <div className="glass relative grid size-36 place-items-center rounded-[40px]">
        <Icon className="size-14 text-primary" strokeWidth={1.75} />
      </div>
    </div>
  );
}

function Onboarding() {
  const [i, setI] = useState(0);
  const navigate = useNavigate();
  const { setMode } = useAppState();
  const done = i >= slides.length;

  return (
    <main className="flex h-full flex-col px-6 pb-8 pt-14">
      <div className="flex items-center justify-between">
        <Wordmark className="text-2xl" />
        {!done && (
          <button className="min-h-11 px-2 text-sm font-semibold text-muted-foreground" onClick={() => setI(slides.length)}>Lewati</button>
        )}
      </div>

      <AnimatePresence mode="wait">
        {!done ? (
          <motion.div
            key={i}
            className="flex flex-1 flex-col justify-center"
            initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}
            drag="x" dragConstraints={{ left: 0, right: 0 }}
            onDragEnd={(_, info) => {
              if (info.offset.x < -60) setI((v) => Math.min(v + 1, slides.length));
              if (info.offset.x > 60) setI((v) => Math.max(v - 1, 0));
            }}
          >
            <Illustration Icon={slides[i]!.icon} />
            <h1 className="mt-10 text-[32px] font-bold leading-tight tracking-tight">{slides[i]!.title}</h1>
            <p className="mt-3 text-base text-muted-foreground">{slides[i]!.text}</p>
          </motion.div>
        ) : (
          <motion.div key="role" className="flex flex-1 flex-col justify-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h1 className="text-[30px] font-bold leading-tight tracking-tight">Kamu pakai Formly sebagai?</h1>
            <p className="mt-2 text-muted-foreground">Gerak benar, hasil lebih aman.</p>
            <div className="mt-8 space-y-3">
              {[
                { icon: Dumbbell, t: "Latihan Mandiri", d: "Gym & olahraga umum", go: () => { setMode("workout"); navigate({ to: "/beranda" }); } },
                { icon: HeartPulse, t: "Pasien (Rehab)", d: "Program dari fisioterapis", go: () => { setMode("rehab"); navigate({ to: "/rehab" }); } },
                { icon: Stethoscope, t: "Terapis", d: "Pantau pasien & buat program", go: () => navigate({ to: "/terapis" }) },
              ].map(({ icon: Icon, t, d, go }) => (
                <motion.button key={t} whileTap={{ scale: 0.98 }} onClick={go} className="w-full text-left">
                  <GlassCard className="flex items-center gap-4 p-4">
                    <div className="grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary"><Icon className="size-6" strokeWidth={1.75} /></div>
                    <div className="flex-1">
                      <div className="font-semibold">{t}</div>
                      <div className="text-sm text-muted-foreground">{d}</div>
                    </div>
                    <ChevronRight className="size-5 text-muted-foreground" strokeWidth={1.75} />
                  </GlassCard>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!done ? (
        <div className="space-y-6">
          <div className="flex justify-center gap-2">
            {slides.map((_, k) => (
              <span key={k} className={`h-2 rounded-full transition-all ${k === i ? "w-6 bg-primary" : "w-2 bg-accent"}`} />
            ))}
          </div>
          <GlassButton size="lg" className="w-full" onClick={() => setI(i + 1)}>{i === slides.length - 1 ? "Mulai" : "Lanjut"}</GlassButton>
        </div>
      ) : (
        <p className="text-center text-xs font-medium text-muted-foreground">Alat bantu latihan, bukan pengganti fisioterapis.</p>
      )}
    </main>
  );
}

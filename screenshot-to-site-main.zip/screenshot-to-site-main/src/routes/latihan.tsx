import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { Search, Smartphone, Check, Camera } from "lucide-react";
import { GlassButton, GlassCard, ScreenTitle, TabScreen } from "@/components/formly/glass";
import { BottomSheet } from "@/components/formly/sheet";
import { ExerciseIcon } from "@/components/formly/ExerciseIcon";
import { exercises, type Exercise } from "@/lib/mock";

export const Route = createFileRoute("/latihan")({
  head: () => ({
    meta: [
      { title: "Latihan — Formly" },
      { name: "description", content: "Pilih gerakan dan pelajari cara menaruh HP serta tips form." },
      { property: "og:title", content: "Latihan — Formly" },
      { property: "og:description", content: "Pustaka gerakan Formly." },
    ],
  }),
  component: Latihan,
});

function Latihan() {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<Exercise | null>(null);
  const navigate = useNavigate();
  const list = exercises.filter((e) => e.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <>
      <TabScreen>
        <ScreenTitle>Latihan</ScreenTitle>
        <label className="glass mb-5 flex min-h-12 items-center gap-3 rounded-full px-5">
          <Search className="size-5 text-muted-foreground" strokeWidth={1.75} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari gerakan" className="flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground" />
        </label>
        <div className="grid grid-cols-2 gap-3">
          {list.map((e) => (
            <motion.button key={e.id} whileTap={{ scale: 0.97 }} onClick={() => setSel(e)} className="text-left">
              <GlassCard className="flex h-full flex-col gap-3 p-4">
                <div className="grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary"><ExerciseIcon icon={e.icon} className="size-6" /></div>
                <div>
                  <div className="font-semibold">{e.name}</div>
                  <div className="text-xs font-medium text-muted-foreground">{e.difficulty}</div>
                </div>
                <span className="inline-flex w-fit items-center gap-1 rounded-full bg-accent px-2.5 py-1 text-xs font-medium text-primary">
                  <Camera className="size-3" strokeWidth={1.75} /> {e.side}
                </span>
              </GlassCard>
            </motion.button>
          ))}
        </div>
        {list.length === 0 && <p className="mt-8 text-center text-muted-foreground">Gerakan tidak ditemukan.</p>}
      </TabScreen>

      <BottomSheet open={!!sel} onClose={() => setSel(null)}>
        {sel && (
          <>
            <h2 className="text-2xl font-bold tracking-tight">{sel.name}</h2>
            <p className="text-sm text-muted-foreground">{sel.difficulty} · Kamera {sel.side.toLowerCase()}</p>
            <h3 className="mb-2 mt-5 flex items-center gap-2 text-sm font-semibold"><Smartphone className="size-4 text-primary" strokeWidth={1.75} /> Cara menaruh HP</h3>
            <p className="text-[15px] text-muted-foreground">{sel.placement}</p>
            <h3 className="mb-2 mt-5 text-sm font-semibold">Kunci form</h3>
            <ul className="space-y-2">
              {sel.tips.map((t) => (
                <li key={t} className="flex gap-2 text-[15px]"><Check className="mt-0.5 size-4 shrink-0 text-success" strokeWidth={2} />{t}</li>
              ))}
            </ul>
            <GlassButton size="lg" className="mt-6 w-full" onClick={() => navigate({ to: "/sesi", search: { ex: sel.id } })}>Mulai</GlassButton>
          </>
        )}
      </BottomSheet>
    </>
  );
}

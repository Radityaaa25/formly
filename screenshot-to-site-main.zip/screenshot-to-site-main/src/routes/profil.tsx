import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, Bell, LogOut } from "lucide-react";
import { GlassCard, TabScreen, Wordmark } from "@/components/formly/glass";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useAppState } from "@/lib/app-state";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/profil")({
  head: () => ({
    meta: [
      { title: "Profil — Formly" },
      { name: "description", content: "Atur mode, suara pelatih, pengingat, dan privasi." },
      { property: "og:title", content: "Profil — Formly" },
      { property: "og:description", content: "Pengaturan akun Formly." },
    ],
  }),
  component: Profil,
});

function Segmented<T extends string>({ value, options, onChange }: { value: T; options: { v: T; l: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="flex rounded-full bg-accent p-1">
      {options.map((o) => (
        <button key={o.v} onClick={() => onChange(o.v)}
          className={cn("min-h-10 flex-1 rounded-full text-sm font-semibold transition-colors", value === o.v ? "bg-card text-primary shadow-sm" : "text-muted-foreground")}>
          {o.l}
        </button>
      ))}
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-3"><div className="text-sm font-semibold">{label}</div>{children}</div>;
}

function Profil() {
  const { mode, setMode } = useAppState();
  const navigate = useNavigate();
  const [vol, setVol] = useState(70);
  const [speed, setSpeed] = useState(50);
  const [detail, setDetail] = useState<"ringkas" | "lengkap">("ringkas");
  const [silent, setSilent] = useState(false);
  const [time, setTime] = useState("18:30");

  return (
    <TabScreen>
      <Wordmark className="text-3xl" />
      <GlassCard className="mt-6 flex items-center gap-4">
        <div className="grid size-14 place-items-center rounded-full bg-primary text-lg font-bold text-primary-foreground btn-gloss">{mode === "rehab" ? "SW" : "RA"}</div>
        <div>
          <div className="text-lg font-bold">{mode === "rehab" ? "Sari Wulandari" : "Raka Pratama"}</div>
          <div className="text-sm text-muted-foreground">{mode === "rehab" ? "Pasien · Fisioterapis Dimas" : "Level 5 · Bandung"}</div>
        </div>
      </GlassCard>

      <GlassCard className="mt-4">
        <Row label="Mode">
          <Segmented value={mode} onChange={(m) => { setMode(m); }} options={[{ v: "workout", l: "Workout" }, { v: "rehab", l: "Rehab" }]} />
        </Row>
      </GlassCard>

      <GlassCard className="mt-4 space-y-6">
        <h2 className="text-lg font-bold">Suara pelatih</h2>
        <Row label={`Volume · ${vol}%`}><Slider value={[vol]} onValueChange={(v) => setVol(v[0] ?? 0)} max={100} aria-label="Volume" /></Row>
        <Row label="Kecepatan bicara"><Slider value={[speed]} onValueChange={(v) => setSpeed(v[0] ?? 0)} max={100} aria-label="Kecepatan bicara" />
          <div className="flex justify-between text-xs font-medium text-muted-foreground"><span>Pelan</span><span>Cepat</span></div></Row>
        <Row label="Tingkat detail"><Segmented value={detail} onChange={setDetail} options={[{ v: "ringkas", l: "Ringkas" }, { v: "lengkap", l: "Lengkap" }]} /></Row>
        <div className="flex min-h-11 items-center justify-between">
          <span className="text-sm font-semibold">Mode senyap</span>
          <Switch checked={silent} onCheckedChange={setSilent} aria-label="Mode senyap" />
        </div>
      </GlassCard>

      <GlassCard className="mt-4">
        <label className="flex min-h-11 items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-sm font-semibold"><Bell className="size-5 text-primary" strokeWidth={1.75} /> Pengingat latihan</span>
          <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="rounded-full bg-accent px-4 py-2 font-semibold text-primary outline-none" />
        </label>
      </GlassCard>

      <GlassCard className="mt-4 flex gap-3">
        <ShieldCheck className="size-6 shrink-0 text-success" strokeWidth={1.75} />
        <div>
          <div className="font-semibold">Privasi</div>
          <p className="mt-1 text-sm text-muted-foreground">Video tidak pernah disimpan. Hanya angka hasil latihan yang tersimpan.</p>
        </div>
      </GlassCard>

      <button onClick={() => navigate({ to: "/" })} className="mt-6 flex min-h-11 w-full items-center justify-center gap-2 text-sm font-semibold text-muted-foreground">
        <LogOut className="size-4" strokeWidth={1.75} /> Ganti peran
      </button>
    </TabScreen>
  );
}

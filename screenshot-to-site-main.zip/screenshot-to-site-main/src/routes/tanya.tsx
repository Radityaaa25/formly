import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Mic, Send } from "lucide-react";
import { ChatBubble, Chip } from "@/components/formly/glass";

export const Route = createFileRoute("/tanya")({
  head: () => ({
    meta: [
      { title: "Tanya Pelatih — Formly" },
      { name: "description", content: "Tanya pelatih AI soal gerakan dan form latihanmu." },
      { property: "og:title", content: "Tanya Pelatih — Formly" },
      { property: "og:description", content: "Tanya pelatih AI soal gerakan dan form." },
    ],
  }),
  component: Tanya,
});

const answers: Record<string, string> = {
  "Kenapa lutut saya terasa tegang?": "Biasanya karena lutut maju melewati ujung kaki atau berat badan bertumpu di depan. Coba dorong pinggul ke belakang dan tekan lewat tumit. Kalau nyeri tajam, berhenti dulu ya.",
  "Gerakan pengganti squat?": "Coba Glute Bridge atau Wall Sit. Keduanya melatih otot yang sama dengan tekanan lebih ringan di lutut.",
  "Berapa lama istirahat antar set?": "Untuk latihan ringan, 45-90 detik sudah cukup. Dengarkan tubuhmu.",
};

function Tanya() {
  const [msgs, setMsgs] = useState<{ from: "user" | "ai"; text: string }[]>([
    { from: "ai", text: "Halo Raka! Ada yang mau ditanyakan soal latihanmu hari ini?" },
  ]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);

  const send = (text: string) => {
    if (!text.trim()) return;
    setMsgs((m) => [...m, { from: "user", text }]);
    setInput("");
    setTimeout(() => {
      setMsgs((m) => [...m, { from: "ai", text: answers[text] ?? "Pertanyaan bagus. Fokus pada gerakan pelan dan terkontrol dulu, lalu tambah repetisi bertahap." }]);
    }, 700);
  };

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-3 px-4 pb-3 pt-12">
        <Link to="/beranda" aria-label="Kembali" className="glass grid size-11 place-items-center rounded-full"><ArrowLeft className="size-5" strokeWidth={1.75} /></Link>
        <h1 className="text-xl font-bold tracking-tight">Tanya Pelatih</h1>
      </header>
      <div className="no-scrollbar flex-1 space-y-3 overflow-y-auto px-4 py-2">
        {msgs.map((m, i) => <ChatBubble key={i} from={m.from}>{m.text}</ChatBubble>)}
      </div>
      <div className="px-4 pb-6 pt-2">
        <div className="no-scrollbar -mx-4 mb-3 flex gap-2 overflow-x-auto px-4">
          {Object.keys(answers).map((q) => <Chip key={q} onClick={() => send(q)}>{q}</Chip>)}
        </div>
        <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="glass flex items-center gap-2 rounded-full p-1.5 pl-5">
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={listening ? "Mendengarkan…" : "Tulis pertanyaan"} className="flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground" />
          <button type="button" aria-label="Tanya dengan suara" onClick={() => setListening((l) => !l)}
            className={`relative grid size-11 place-items-center rounded-full ${listening ? "bg-primary text-primary-foreground" : "text-primary"}`}>
            {listening && <span className="animate-pulse-ring absolute inset-0 rounded-full bg-primary/40" />}
            <Mic className="relative size-5" strokeWidth={1.75} />
          </button>
          <button type="submit" aria-label="Kirim" className="btn-gloss grid size-11 place-items-center rounded-full bg-primary text-primary-foreground"><Send className="size-5" strokeWidth={1.75} /></button>
        </form>
        <p className="mt-2 text-center text-xs font-medium text-muted-foreground">Bukan pengganti nasihat medis</p>
      </div>
    </div>
  );
}

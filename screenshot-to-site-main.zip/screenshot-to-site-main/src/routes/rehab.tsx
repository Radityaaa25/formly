import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CheckCircle2, Circle, Play } from "lucide-react";
import { GlassButton, GlassCard, StatRing, TabScreen } from "@/components/formly/glass";
import { ExerciseIcon } from "@/components/formly/ExerciseIcon";
import { exercises, rehabProgram } from "@/lib/mock";

export const Route = createFileRoute("/rehab")({
  head: () => ({
    meta: [
      { title: "Program Rehab — Formly" },
      { name: "description", content: "Program latihan hari ini dari fisioterapismu." },
      { property: "og:title", content: "Program Rehab — Formly" },
      { property: "og:description", content: "Program latihan hari ini dari fisioterapismu." },
    ],
  }),
  component: Rehab,
});

function Rehab() {
  const navigate = useNavigate();
  const next = rehabProgram.find((p) => !p.done) ?? rehabProgram[0]!;
  return (
    <TabScreen>
      <div className="mb-6 flex items-center gap-3">
        <div className="grid size-11 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground btn-gloss">SW</div>
        <div>
          <p className="text-xs font-medium text-muted-foreground">Sabtu, 7 November</p>
          <h1 className="text-[26px] font-bold leading-tight tracking-tight">Halo, Sari</h1>
        </div>
      </div>

      <GlassCard className="flex items-center gap-5 p-6">
        <StatRing value={5} max={6} size={104}>
          <span className="text-2xl font-bold">5<span className="text-base text-muted-foreground">/6</span></span>
        </StatRing>
        <div>
          <p className="font-semibold">5 dari 6 sesi minggu ini</p>
          <p className="mt-1 text-sm text-muted-foreground">Pelan-pelan saja, yang penting rutin.</p>
        </div>
      </GlassCard>

      <h2 className="mb-1 mt-7 text-lg font-bold tracking-tight">Program hari ini</h2>
      <p className="mb-4 text-sm text-muted-foreground">dari Fisioterapis Dimas</p>
      <div className="space-y-3">
        {rehabProgram.map((p) => {
          const ex = exercises.find((e) => e.id === p.id)!;
          return (
            <GlassCard key={p.id} className="flex items-center gap-4 p-4">
              <div className="grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary"><ExerciseIcon icon={ex.icon} className="size-6" /></div>
              <div className="flex-1">
                <div className="font-semibold">{p.name}</div>
                <div className="text-sm text-muted-foreground">{p.sets} set × {p.reps} rep</div>
              </div>
              {p.done
                ? <CheckCircle2 className="size-6 text-success" strokeWidth={1.75} aria-label="Selesai" />
                : <Circle className="size-6 text-muted-foreground/40" strokeWidth={1.75} aria-label="Belum" />}
            </GlassCard>
          );
        })}
      </div>

      <GlassButton size="lg" className="mt-6 w-full" onClick={() => navigate({ to: "/sesi", search: { ex: next.id } })}>
        <Play className="size-5" strokeWidth={1.75} /> Mulai {next.name}
      </GlassButton>
    </TabScreen>
  );
}

import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, Plus } from "lucide-react";
import { GlassCard, StatusBadge } from "@/components/formly/glass";
import { TherapistShell } from "@/components/formly/TherapistShell";
import { patients, statusTone } from "@/lib/mock";

export const Route = createFileRoute("/terapis/")({
  head: () => ({
    meta: [
      { title: "Pasien — Formly Terapis" },
      { name: "description", content: "Daftar pasien dan status kepatuhan latihan." },
      { property: "og:title", content: "Pasien — Formly Terapis" },
      { property: "og:description", content: "Pantau kepatuhan latihan pasien." },
    ],
  }),
  component: TerapisList,
});


function TerapisList() {
  return (
    <TherapistShell
      title="Pasien"
      action={<Link to="/terapis/program" className="btn-gloss flex min-h-11 items-center gap-1.5 rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground"><Plus className="size-4" strokeWidth={2} /> Program</Link>}
    >
      <p className="mb-4 text-sm text-muted-foreground">Fisioterapis Dimas · {patients.length} pasien aktif</p>
      <GlassCard className="divide-y divide-border/60 p-0">
        {patients.map((p) => (
          <Link key={p.id} to="/terapis/$id" params={{ id: p.id }} className="flex min-h-16 items-center gap-3 px-4 py-3">
            <div className="grid size-10 place-items-center rounded-full bg-primary/10 text-sm font-bold text-primary">{p.name.split(" ").map((n) => n.charAt(0)).join("")}</div>
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{p.name}</div>
              <div className="truncate text-xs text-muted-foreground">{p.condition} · {p.lastSession}</div>
            </div>
            <StatusBadge tone={statusTone(p.status)}>{p.status}</StatusBadge>
            <ChevronRight className="size-4 text-muted-foreground" strokeWidth={1.75} />
          </Link>
        ))}
      </GlassCard>
    </TherapistShell>
  );
}

import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { Check, Volume2, Award, Lightbulb, Flame } from "lucide-react";
import { CountUp, GlassButton, GlassCard, TabScreen } from "@/components/formly/glass";
import { PainSlider } from "@/components/formly/PainSlider";
import { useAppState } from "@/lib/app-state";

export const Route = createFileRoute("/ringkasan")({
  head: () => ({
    meta: [
      { title: "Ringkasan Sesi — Formly" },
      { name: "description", content: "Hasil sesi: rep, skor form, durasi, dan saran dari pelatih AI." },
      { property: "og:title", content: "Ringkasan Sesi — Formly" },
      { property: "og:description", content: "Hasil sesi latihanmu." },
    ],
  }),
  component: Ringkasan,
});

function Ringkasan() {
  const { mode } = useAppState();
  const navigate = useNavigate();
  const workout = mode === "workout";
  const [pain, setPain] = useState(2);
  const [playing, setPlaying] = useState(false);

  return (
    <TabScreen nav={false}>
      <div className="flex flex-col items-center text-center">
        <div className="relative grid size-24 place-items-center">
          <motion.svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
            <motion.circle cx="50" cy="50" r="45" stroke="var(--primary)" strokeWidth="6" fill="none" strokeLinecap="round"
              initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.8 }} />
          </motion.svg>
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.6, type: "spring" }}>
            <Check className="size-10 text-primary" strokeWidth={2} />
          </motion.div>
        </div>
        <h1 className="mt-4 text-[30px] font-bold tracking-tight">Sesi selesai</h1>
        {workout ? (
          <p className="mt-1 inline-flex items-center gap-1.5 font-semibold text-primary"><Flame className="size-4" strokeWidth={1.75} /> Streak 13 hari</p>
        ) : (
          <p className="mt-1 text-muted-foreground">Kerja bagus. Terapismu akan melihat hasil ini.</p>
        )}
      </div>

      <div className="mt-6 grid grid-cols-3 gap-3">
        {[
          { l: "Rep", v: <CountUp to={30} /> },
          { l: "Skor form", v: <CountUp to={86} /> },
          { l: "Durasi", v: "08:12" },
        ].map((s) => (
          <GlassCard key={s.l} className="p-4 text-center">
            <div className="text-2xl font-extrabold">{s.v}</div>
            <div className="text-xs font-medium text-muted-foreground">{s.l}</div>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="mt-4">
        <h2 className="mb-3 text-sm font-semibold text-muted-foreground">Kesalahan yang sering muncul</h2>
        <ul className="space-y-3">
          <li className="flex justify-between"><span>Kurang dalam saat turun</span><span className="font-semibold text-warning">6×</span></li>
          <li className="flex justify-between"><span>Lutut sedikit masuk ke dalam</span><span className="font-semibold text-warning">3×</span></li>
        </ul>
      </GlassCard>

      <GlassCard className="mt-4">
        <p className="text-[15px] leading-relaxed">
          Gerakanmu stabil dari awal sampai akhir. Skor form naik 4 poin dari sesi lalu. Di set terakhir kedalaman squat mulai berkurang.
        </p>
        <p className="mt-3 flex gap-2 text-[15px] font-medium text-primary">
          <Lightbulb className="mt-0.5 size-4 shrink-0" strokeWidth={1.75} /> Tips: dorong pinggul ke belakang seperti mau duduk.
        </p>
        <GlassButton variant="secondary" className="mt-4" onClick={() => setPlaying((p) => !p)}>
          <Volume2 className="size-4" strokeWidth={1.75} /> {playing ? "Memutar…" : "Dengarkan"}
        </GlassButton>
      </GlassCard>

      {workout ? (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1, type: "spring" }}>
          <GlassCard className="relative mt-4 flex items-center gap-4 overflow-hidden">
            {[...Array(8)].map((_, i) => (
              <motion.span key={i} className="absolute size-1.5 rounded-full bg-sky"
                style={{ left: `${10 + i * 11}%`, top: "50%" }}
                initial={{ y: 0, opacity: 1 }} animate={{ y: -40 - (i % 3) * 15, opacity: 0 }} transition={{ delay: 1.2 + i * 0.05, duration: 1 }} />
            ))}
            <div className="grid size-14 place-items-center rounded-full bg-primary text-primary-foreground btn-gloss"><Award className="size-7" strokeWidth={1.75} /></div>
            <div className="flex-1">
              <p className="text-xs font-medium text-muted-foreground">Badge baru</p>
              <p className="font-bold">7 Hari Beruntun</p>
            </div>
            <span className="text-xl font-extrabold text-primary">+45 XP</span>
          </GlassCard>
        </motion.div>
      ) : (
        <GlassCard className="mt-4">
          <h2 className="mb-4 font-semibold">Setelah sesi</h2>
          <PainSlider value={pain} onChange={setPain} />
        </GlassCard>
      )}

      <GlassButton size="lg" className="mt-6 w-full" onClick={() => navigate({ to: workout ? "/beranda" : "/rehab" })}>Kembali ke Beranda</GlassButton>
    </TabScreen>
  );
}

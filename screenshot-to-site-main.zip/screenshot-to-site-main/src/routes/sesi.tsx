import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Mic, X, Pause, Play, Check, Smartphone } from "lucide-react";
import { GlassButton } from "@/components/formly/glass";
import { BottomSheet } from "@/components/formly/sheet";
import { PainSlider } from "@/components/formly/PainSlider";
import { exercises } from "@/lib/mock";
import { useAppState } from "@/lib/app-state";

export const Route = createFileRoute("/sesi")({
  validateSearch: (s: Record<string, unknown>): { ex?: string | undefined } => ({ ex: typeof s["ex"] === "string" ? s["ex"] : undefined }),
  head: () => ({
    meta: [
      { title: "Sesi Latihan — Formly" },
      { name: "description", content: "Sesi latihan dengan hitungan rep dan koreksi form lewat suara." },
      { property: "og:title", content: "Sesi Latihan — Formly" },
      { property: "og:description", content: "Hitungan rep dan koreksi form real-time." },
    ],
  }),
  component: Sesi,
});

const cues = ["Turun sedikit lagi", "Bagus, pertahankan", "Punggung tetap lurus", "Lutut searah ujung kaki"];

function Skeleton() {
  const j = "var(--sky)";
  return (
    <svg viewBox="0 0 200 320" className="animate-bob h-[62%] drop-shadow-[0_0_12px_var(--sky)]">
      <g stroke={j} strokeWidth="3.5" strokeLinecap="round" fill="none" opacity="0.9">
        <line x1="100" y1="60" x2="100" y2="150" />
        <line x1="100" y1="80" x2="65" y2="120" /><line x1="65" y1="120" x2="55" y2="160" />
        <line x1="100" y1="80" x2="135" y2="120" /><line x1="135" y1="120" x2="145" y2="160" />
        <line x1="100" y1="150" x2="75" y2="215" /><line x1="75" y1="215" x2="80" y2="290" />
        <line x1="100" y1="150" x2="125" y2="215" /><line x1="125" y1="215" x2="120" y2="290" />
      </g>
      <circle cx="100" cy="38" r="16" stroke={j} strokeWidth="3" fill="none" />
      {[[100,80],[65,120],[55,160],[135,120],[145,160],[100,150],[75,215],[80,290],[125,215],[120,290]].map(([x,y],i)=>(
        <circle key={i} cx={x} cy={y} r="5" fill="var(--cam-foreground)" stroke={j} strokeWidth="2" />
      ))}
    </svg>
  );
}

function Sesi() {
  const { ex } = Route.useSearch();
  const exercise = exercises.find((e) => e.id === ex) ?? exercises[0]!;
  const navigate = useNavigate();
  const { mode } = useAppState();
  const [phase, setPhase] = useState<"pain" | "setup" | "count" | "live">(mode === "rehab" ? "pain" : "setup");
  const [count, setCount] = useState(3);
  const [reps, setReps] = useState(0);
  const [paused, setPaused] = useState(false);
  const [pain, setPain] = useState(2);
  const target = 10;

  useEffect(() => {
    if (phase !== "count") return;
    if (count === 0) { setPhase("live"); return; }
    const t = setTimeout(() => setCount((c) => c - 1), 900);
    return () => clearTimeout(t);
  }, [phase, count]);

  useEffect(() => {
    if (phase !== "live" || paused || reps >= target) return;
    const t = setTimeout(() => setReps((r) => r + 1), 1600);
    return () => clearTimeout(t);
  }, [phase, paused, reps]);

  const finish = () => navigate({ to: "/ringkasan" });
  const close = () => navigate({ to: mode === "rehab" ? "/rehab" : "/beranda" });

  return (
    <div className="relative h-full overflow-hidden bg-cam text-cam-foreground">
      <div className="absolute inset-0 grid place-items-center"><Skeleton /></div>

      <div className="glass-dark absolute inset-x-4 top-12 flex items-center justify-between rounded-full py-2 pl-5 pr-2">
        <span className="text-lg font-bold">{exercise.name}</span>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-2 text-sm font-medium">
            <span className="relative grid size-8 place-items-center">
              {!paused && <span className="animate-pulse-ring absolute inset-0 rounded-full bg-sky/50" />}
              <Mic className="relative size-5 text-sky" strokeWidth={1.75} />
            </span>
            {paused ? "Dijeda" : "Mendengarkan"}
          </span>
          <button aria-label="Hentikan sesi" onClick={close} className="grid size-11 place-items-center rounded-full bg-cam-foreground/15">
            <X className="size-5" strokeWidth={1.75} />
          </button>
        </div>
      </div>

      {phase === "live" && (
        <div className="absolute inset-x-0 bottom-6 flex flex-col items-center px-4">
          <AnimatePresence mode="wait">
            <motion.div key={reps % cues.length} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="glass-dark mb-4 rounded-full px-6 py-3 text-lg font-semibold">
              {reps >= target ? "Set selesai, kerja bagus!" : cues[reps % cues.length]}
            </motion.div>
          </AnimatePresence>
          <div className="mb-5 text-center">
            <motion.span key={reps} initial={{ scale: 1.15 }} animate={{ scale: 1 }} className="inline-block text-8xl font-extrabold tracking-tight">{reps}</motion.span>
            <span className="text-4xl font-bold opacity-60"> / {target}</span>
          </div>
          <div className="glass-dark flex w-full items-center gap-3 rounded-3xl p-3">
            <div className="px-3 text-center">
              <div className="text-3xl font-extrabold text-sky">86</div>
              <div className="text-xs font-medium opacity-75">Skor form</div>
            </div>
            <button onClick={() => setPaused((p) => !p)} className="flex min-h-14 flex-1 items-center justify-center gap-2 rounded-full bg-cam-foreground/15 font-semibold">
              {paused ? <Play className="size-5" strokeWidth={1.75} /> : <Pause className="size-5" strokeWidth={1.75} />}{paused ? "Lanjut" : "Jeda"}
            </button>
            <GlassButton size="lg" className="flex-1" onClick={finish}><Check className="size-5" strokeWidth={1.75} /> Selesai</GlassButton>
          </div>
          <p className="mt-3 text-sm opacity-70">Katakan 'jeda' atau 'berhenti'</p>
        </div>
      )}

      <AnimatePresence>
        {phase === "count" && count > 0 && (
          <motion.div key={count} className="absolute inset-0 grid place-items-center bg-cam/50"
            initial={{ opacity: 0, scale: 1.3 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}>
            <span className="text-[140px] font-extrabold">{count}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="text-foreground">
        <BottomSheet open={phase === "pain"}>
          <h2 className="text-2xl font-bold tracking-tight">Sebelum mulai</h2>
          <p className="mb-6 mt-1 text-muted-foreground">Bagaimana rasa nyerimu sekarang?</p>
          <PainSlider value={pain} onChange={setPain} />
          <GlassButton size="lg" className="mt-6 w-full" onClick={() => setPhase("setup")}>Lanjut</GlassButton>
        </BottomSheet>
        <BottomSheet open={phase === "setup"}>
          <div className="mb-4 grid size-14 place-items-center rounded-2xl bg-primary/10 text-primary"><Smartphone className="size-7" strokeWidth={1.75} /></div>
          <h2 className="text-2xl font-bold tracking-tight">Siapkan posisi</h2>
          <p className="mt-2 text-base text-muted-foreground">Taruh HP 2-3 meter, seluruh badan terlihat.</p>
          <p className="mt-1 text-sm text-muted-foreground">{exercise.placement}</p>
          <GlassButton size="lg" className="mt-6 w-full" onClick={() => { setCount(3); setPhase("count"); }}>Saya siap</GlassButton>
        </BottomSheet>
      </div>
    </div>
  );
}

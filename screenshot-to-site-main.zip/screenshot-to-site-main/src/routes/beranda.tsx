import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Flame, Snowflake, MessageCircle, Play } from "lucide-react";
import { motion } from "framer-motion";
import { Chip, CountUp, GlassButton, GlassCard, ProgressBar, StatRing, StreakWeek, TabScreen } from "@/components/formly/glass";
import { ExerciseIcon } from "@/components/formly/ExerciseIcon";
import { exercises } from "@/lib/mock";

export const Route = createFileRoute("/beranda")({
  head: () => ({
    meta: [
      { title: "Beranda — Formly" },
      { name: "description", content: "Streak, target mingguan, dan latihan hari ini." },
      { property: "og:title", content: "Beranda — Formly" },
      { property: "og:description", content: "Streak, target mingguan, dan latihan hari ini." },
    ],
  }),
  component: Beranda,
});

function Beranda() {
  const navigate = useNavigate();
  return (
    <>
      <TabScreen>
        <div className="mb-6 flex items-center gap-3">
          <div className="grid size-11 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground btn-gloss">RA</div>
          <div>
            <p className="text-xs font-medium text-muted-foreground">Sabtu, 7 November</p>
            <h1 className="text-[26px] font-bold leading-tight tracking-tight">Halo, Raka</h1>
          </div>
        </div>

        <GlassCard className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-baseline gap-2">
                <CountUp to={12} className="text-6xl font-extrabold tracking-tight text-primary" />
                <Flame className="size-7 text-sky" strokeWidth={1.75} />
              </div>
              <p className="font-semibold">hari beruntun</p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-sky/15 px-3 py-1.5 text-xs font-semibold text-primary">
              <Snowflake className="size-3.5" strokeWidth={1.75} /> Streak Freeze: 1 tersedia
            </span>
          </div>
          <div className="mt-6"><StreakWeek active={[true, true, true, true, true, false, false]} today={5} /></div>
          <p className="mt-5 text-sm text-muted-foreground">Latihan hari ini untuk menjaga streak</p>
        </GlassCard>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <GlassCard className="flex flex-col items-center gap-2">
            <StatRing value={4} max={5}><span className="text-2xl font-bold">4<span className="text-base text-muted-foreground">/5</span></span></StatRing>
            <span className="text-xs font-medium text-muted-foreground">4 dari 5 hari</span>
          </GlassCard>
          <GlassCard className="flex flex-col justify-between">
            <p className="text-xs font-medium text-muted-foreground">Latihan hari ini</p>
            <p className="text-lg font-bold leading-tight">Squat<br /><span className="text-sm font-medium text-muted-foreground">3 × 10 rep</span></p>
            <GlassButton className="mt-2 w-full" onClick={() => navigate({ to: "/sesi", search: { ex: "squat" } })}>
              <Play className="size-4" strokeWidth={1.75} /> Mulai Latihan
            </GlassButton>
          </GlassCard>
        </div>

        <h2 className="mb-3 mt-7 text-sm font-semibold text-muted-foreground">Pilih cepat</h2>
        <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 pb-1">
          {exercises.slice(0, 4).map((e) => (
            <Chip key={e.id} onClick={() => navigate({ to: "/sesi", search: { ex: e.id } })}>
              <ExerciseIcon icon={e.icon} className="size-4 text-primary" /> {e.name}
            </Chip>
          ))}
        </div>

        <GlassCard className="mt-6">
          <div className="mb-3 flex justify-between text-sm">
            <span className="font-semibold">Level 5</span>
            <span className="font-medium text-muted-foreground">340 / 500 XP</span>
          </div>
          <ProgressBar value={340} max={500} />
        </GlassCard>
      </TabScreen>

      <motion.div whileTap={{ scale: 0.95 }} className="absolute bottom-28 right-5 z-20">
        <Link to="/tanya" className="glass flex min-h-12 items-center gap-2 rounded-full px-4 text-sm font-semibold text-primary">
          <MessageCircle className="size-5" strokeWidth={1.75} /> Tanya Pelatih
        </Link>
      </motion.div>
    </>
  );
}
